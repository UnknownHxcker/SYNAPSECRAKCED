Welcome to SynapseCracked! We are glad to have you here.

To start, run Synapse Launcher.exe.

If you need any help DM MEME#6999 to get help this might have some problem because this still in BETA.

Enjoy!